package com.gateways;

public abstract class AbstractPlugin {
	public abstract void start(String n);
}
