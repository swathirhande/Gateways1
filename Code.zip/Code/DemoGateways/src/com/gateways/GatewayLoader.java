package com.gateways;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import com.pluginlistcalling.AbstractPlugin;
import com.pluginlistcalling.PluginLoader;
import com.pluginlistcalling.PluginLoader.PluginData;

public class GatewayLoader {
	public void GetDetail(String n) {
		final File plugin_list = new File("C:\\Demo\\plugins.txt");
		try {
			PluginLoader.parseConfig(plugin_list, null);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		final HashMap<String, PluginData> plugin_datas = PluginLoader.getPlugins();

		final AbstractPlugin[] plugins = new AbstractPlugin[plugin_datas.size()];

		try {
			int i = 0;
			for (String key : plugin_datas.keySet()) {
				plugins[i++] = PluginLoader.newInstance(plugin_datas.get(key));
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}

		for (AbstractPlugin plugin : plugins) {
			plugin.start(n);
		}

		// TODO Auto-generated method stub

	}

	public static void main(String args[]) {
		// String input = args[0];
		GatewayLoader gt = new GatewayLoader();
		// gt.GetDetail(input);
		gt.GetDetail("usha98123'1'!");
	}

}
