package com.pluginlist8;

import com.pluginlistcalling.AbstractPlugin;

public class Plugin8 extends AbstractPlugin {

	@Override
	public void start(String n) {
		// TODO Auto-generated method stub
		/*
		 * int a; Pattern pattern = Pattern.compile("[^A-Za-z0-9]"); Matcher match =
		 * pattern.matcher(n); boolean val = match.find(); if (val == true) { a = 1;
		 * System.out.println(a); } else { a = 0; System.out.println(a); }
		 */
		System.out.println("PLUGIN CALLED");
	}
}
